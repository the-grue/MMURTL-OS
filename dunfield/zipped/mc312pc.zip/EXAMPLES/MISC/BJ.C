/*
 * Very simple BLACKJACK (21) game
 *
 * Compile command: cc bj -fop
 */
#include <stdio.h>
#define	DECK	52
#define	SUITES	4

extern int RAND_SEED;

main()
{
	int deck[DECK], i, j, t, player_total, dealer_total, next_card;

	player_total = dealer_total = next_card = 0;

	/* Initialize random seed */
	get_time(&i, &j, &t);
	RAND_SEED = (i*3600) + (j*60) + t;

	/* Deal a deck of cards */
	for(i=0; i < DECK; ++i)
		deck[i] = i;
	for(i=0; i < DECK; ++i) {
		t = deck[i];
		deck[i] = deck[j = rand(DECK)];
		deck[j] = t; }

	/* Accept player cards */
	for(;;) {
		printf("Player: %-4u", player_total);
		if(player_total > 21)
			abort("You BUST!");
		if(get_input("Another card (Y/N)", "YN") == 'N')
			break;
		show_card(i = deck[next_card++]);
		if(!(i %= (DECK/SUITES))) {
			if(get_input("1 or Ten?", "1T") == 'T')
				i = 9; }
		player_total += (i > 9) ? 10 : i+1; }

	/* Play dealer */
	for(;;) {
		printf("Dealer: %-4u", dealer_total);
		if(dealer_total > 21)
			abort("You WIN!");
		if(dealer_total >= player_total)
			abort("Dealer wins!");
		show_card(i = deck[next_card++]);
		if(!(i %= (DECK/SUITES))) {
			t = dealer_total + 10;
			if((t < 22) && ((t >= player_total) || (t < 10)))
				i = 9;
			printf("Dealer choses: %u\n", i+1); }
		dealer_total += (i > 9) ? 10 : i+1; }
}

/*
 * Get input character with prompt, and validate
 */
get_input(char prompt[], char allowed[])
{
	int i;
	char buffer[50], *ptr, c;

	for(;;) {
		printf("%s?", prompt);
		fgets(ptr = buffer, sizeof(buffer)-1, stdin);
		while(isspace(c = toupper(*ptr)))
			++ptr;
		for(i = 0; allowed[i]; ++i)
			if(c == allowed[i])
				return c;
		printf("Huh?\n"); }
}

/*
 * Display a card
 */
show_card(int card)
{
	static char *suites[] = { "Hearts", "Diamonds", "Clubs", "Spades" };
	static char *cards[] = { "Ace", "Two", "Three", "Four", "Five", "Six",
		"Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King" };

	printf("%s of %s\n", cards[card % (DECK/SUITES)], suites[card / (DECK/SUITES)]);
}
