/*
 * Very simple program to find prime numbers.
 * Note: 2 is neither tested nor displayed by this program.
 *
 * Compile command: cc prime -fop
 */
#include <stdio.h>

#define	MAXPRIME	1000		/* Search up to here */

/*
 * Main (and only) function
 */
main()
{
	int num, test, limit;
	char flag;

	for(num=1; num < MAXPRIME; num += 2) {	/* Test range */
		limit = num/2;						/* Only test to here */
		flag = 1;							/* Assume prime */
		for(test = 2; test <= limit; ++test) {	/* Test for factors */
			if(!(num%test)) {				/* No remainder: factor */
				flag = 0;					/* Indicate not prime */
				break; } }					/* Waste no more time */ 
		if(flag)							/* Prime number, display */
			printf("%d\n", num); }
}
